# Pet-Rescue-Saga
to launch game on every OS with java 16:
java -jar PRS.jar


to compile game on linux/mac:
./javac.sh
to jar .class file on linux/mac:
./jar.sh
